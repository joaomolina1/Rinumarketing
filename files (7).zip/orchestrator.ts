/**
 * RINU Marketing AI — Agente Orquestrador Central
 *
 * Responsabilidades:
 * 1. Receber trigger (scheduled | manual | alert)
 * 2. Chamar os 3 agentes especialistas em paralelo
 * 3. Agregar resultados e resolver conflitos de budget
 * 4. Priorizar acções por impacto e risco
 * 5. Persistir tudo no Supabase (agent_runs + agent_actions)
 * 6. Notificar via Slack se houver acções pendentes ou alertas críticos
 */

import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/types/database";
import { runGoogleAgent } from "./google-agent";
import { runMetaAgent } from "./meta-agent";
import { runAnalyticsAgent } from "./analytics-agent";
import { getRecentDecisions, saveDecision } from "./memory";
import { notifySlack } from "@/lib/notifications/slack";

// ─── Types ────────────────────────────────────────────────────────────────────

export type TriggerType = "scheduled_daily" | "scheduled_weekly" | "manual" | "alert";
export type RiskLevel = "low" | "medium" | "high";
export type ActionStatus = "pending" | "approved" | "rejected" | "executed" | "failed";
export type Platform = "google" | "meta";
export type EntityType = "campaign" | "ad_group" | "keyword" | "ad";

export interface AgentAction {
  action_type: string;
  platform: Platform;
  entity_type: EntityType;
  entity_id: string;
  entity_name?: string;
  current_value: Record<string, unknown>;
  proposed_value: Record<string, unknown>;
  reasoning: string;
  expected_impact: string;
  risk_level: RiskLevel;
}

export interface AgentResult {
  agent_name: string;
  analysis: string;
  actions: AgentAction[];
  alerts: string[];
  error?: string;
}

export interface OrchestratorInput {
  trigger: TriggerType;
  date_range_days?: number;       // default: 7
  focus_platform?: Platform;      // se definido, analisa apenas essa plataforma
  manual_instruction?: string;    // instrução adicional para análise manual
}

export interface OrchestratorOutput {
  run_id: string;
  trigger: TriggerType;
  analysis_summary: string;
  actions_proposed: AgentAction[];
  actions_requiring_approval: AgentAction[];
  auto_approved_actions: AgentAction[];
  alerts: string[];
  agent_results: AgentResult[];
  total_budget_at_risk_eur: number;
  started_at: string;
  completed_at: string;
  duration_ms: number;
}

// ─── Constantes ───────────────────────────────────────────────────────────────

/**
 * Acções de baixo risco aprovadas automaticamente (sem intervenção humana).
 * Apenas activado após a Fase 2 do rollout (≥ 4 semanas sem incidentes).
 *
 * Para activar: definir AUTO_APPROVE_ENABLED=true nas env vars.
 */
const AUTO_APPROVE_RULES: Record<string, boolean> = {
  // bid adjustment ≤ 20%: auto-aprovado se risco 'low'
  adjust_bid_low: process.env.AUTO_APPROVE_ENABLED === "true",
  // pausa de keyword com 0 conversões em 14 dias: auto-aprovado
  pause_zero_conversion_keyword: process.env.AUTO_APPROVE_ENABLED === "true",
};

const MAX_BUDGET_CHANGE_AUTO_EUR = 50; // nunca auto-aprovar alterações de budget > €50/dia

const ORCHESTRATOR_SYSTEM_PROMPT = `
És o orquestrador central do sistema de marketing digital da RINU, uma plataforma de aluguer de espaços para eventos em Portugal.

Recebes os resultados de 3 agentes especialistas (Google Ads, Meta Ads, Analytics) e a tua tarefa é:

1. SINTETIZAR os resultados numa análise coerente e accionável
2. RESOLVER CONFLITOS: se o agente Google e o agente Meta disputam o mesmo budget, prioriza o canal com melhor ROAS histórico
3. PRIORIZAR ACÇÕES por: (a) impacto potencial em €, (b) urgência, (c) risco
4. IDENTIFICAR padrões cross-canal que nenhum agente viu individualmente
5. GERAR um executive summary em português de Portugal, conciso e directo

CONTEXTO DO NEGÓCIO:
- RINU opera em Portugal (Lisboa = 66% do volume)
- Ticket médio: €500–€5.000 por reserva de espaço
- Budget total mensal tipicamente: €2.000–€8.000 entre Google e Meta
- ROAS alvo blended: > 4x
- CPA alvo: < €80 por lead qualificado

REGRAS DE PRIORIZAÇÃO:
- CRÍTICO (executar hoje): anomalias de spend > 50% do esperado, ROAS < 1x
- ALTA (executar hoje): ROAS < 2x há > 3 dias, budget a esgotar antes das 14h
- MÉDIA (executar esta semana): optimizações de bid, creative fatigue
- BAIXA (backlog): testes A/B, expansão de audiências

REGRAS DE CONFLITO DE BUDGET:
- Nunca propor aumento total de spend > 30% sem justificação explícita
- Se ambos os canais pedem aumento: priorizar o com maior ROAS nos últimos 7 dias
- Manter sempre pelo menos 20% do budget no canal com melhor performance histórica

FORMATO DE OUTPUT (JSON estrito):
{
  "analysis_summary": "string — 3-5 frases em PT-PT",
  "cross_channel_insights": ["string"],
  "priority_actions": [
    {
      "priority": "critical|high|medium|low",
      "action_index": 0,
      "override_reasoning": "string — porquê desta prioridade"
    }
  ],
  "budget_conflicts_resolved": ["string — descrição de cada conflito resolvido"],
  "weekly_outlook": "string — previsão para os próximos 7 dias"
}
`.trim();

// ─── Cliente Supabase (server-side) ───────────────────────────────────────────

function getSupabaseAdmin() {
  return createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

// ─── Função principal ─────────────────────────────────────────────────────────

export async function runOrchestrator(
  input: OrchestratorInput
): Promise<OrchestratorOutput> {
  const supabase = getSupabaseAdmin();
  const startedAt = new Date();
  const dateRangeDays = input.date_range_days ?? 7;

  // 1. Criar registo da run no Supabase (status: running)
  const { data: runRecord, error: runCreateError } = await supabase
    .from("agent_runs")
    .insert({
      agent_name: "orchestrator",
      trigger_type: input.trigger,
      status: "running",
      input: input as Record<string, unknown>,
    })
    .select("id")
    .single();

  if (runCreateError || !runRecord) {
    throw new Error(`Falha ao criar agent_run: ${runCreateError?.message}`);
  }

  const runId = runRecord.id;

  try {
    // 2. Recuperar decisões recentes (memória do sistema)
    const recentDecisions = await getRecentDecisions({ days: 14, limit: 20 });

    // 3. Correr os 3 agentes em paralelo
    const [googleResult, metaResult, analyticsResult] = await Promise.allSettled([
      input.focus_platform === "meta"
        ? Promise.resolve(null)
        : runGoogleAgent({ days: dateRangeDays, recent_decisions: recentDecisions }),
      input.focus_platform === "google"
        ? Promise.resolve(null)
        : runMetaAgent({ days: dateRangeDays, recent_decisions: recentDecisions }),
      runAnalyticsAgent({ days: dateRangeDays, recent_decisions: recentDecisions }),
    ]);

    // 4. Normalizar resultados (tratar erros individuais sem falhar o todo)
    const agentResults: AgentResult[] = [];
    const allActions: AgentAction[] = [];
    const allAlerts: string[] = [];

    for (const [name, result] of [
      ["google", googleResult],
      ["meta", metaResult],
      ["analytics", analyticsResult],
    ] as [string, PromiseSettledResult<AgentResult | null>][]) {
      if (result.status === "fulfilled" && result.value) {
        agentResults.push(result.value);
        allActions.push(...result.value.actions);
        allAlerts.push(...result.value.alerts);
      } else if (result.status === "rejected") {
        const errorMsg = `Agente ${name} falhou: ${result.reason?.message ?? "erro desconhecido"}`;
        agentResults.push({
          agent_name: name,
          analysis: "",
          actions: [],
          alerts: [errorMsg],
          error: errorMsg,
        });
        allAlerts.push(errorMsg);
      }
    }

    // 5. Orquestrador LLM: sintetizar e priorizar
    const orchestratorAnalysis = await synthesizeWithLLM({
      agentResults,
      allActions,
      allAlerts,
      recentDecisions,
      manualInstruction: input.manual_instruction,
    });

    // 6. Aplicar prioridades e separar acções por aprovação necessária
    const prioritizedActions = applyPriorities(allActions, orchestratorAnalysis.priority_actions);
    const { requiresApproval, autoApproved } = separateByApproval(prioritizedActions);

    // 7. Calcular budget em risco
    const totalBudgetAtRisk = calculateBudgetAtRisk(prioritizedActions);

    // 8. Persistir acções no Supabase
    if (prioritizedActions.length > 0) {
      const actionsToInsert = prioritizedActions.map((action) => ({
        run_id: runId,
        agent_name: deriveAgentName(action.platform),
        action_type: action.action_type,
        platform: action.platform,
        entity_type: action.entity_type,
        entity_id: action.entity_id,
        entity_name: action.entity_name ?? null,
        current_value: action.current_value,
        proposed_value: action.proposed_value,
        reasoning: action.reasoning,
        expected_impact: action.expected_impact,
        risk_level: action.risk_level,
        status: "pending" as ActionStatus,
      }));

      const { error: actionsError } = await supabase
        .from("agent_actions")
        .insert(actionsToInsert);

      if (actionsError) {
        console.error("Erro ao inserir agent_actions:", actionsError.message);
      }
    }

    // 9. Guardar síntese na memória
    await saveDecision({
      run_id: runId,
      summary: orchestratorAnalysis.analysis_summary,
      actions_count: prioritizedActions.length,
      alerts_count: allAlerts.length,
    });

    // 10. Actualizar run como completed
    const completedAt = new Date();
    const output: OrchestratorOutput = {
      run_id: runId,
      trigger: input.trigger,
      analysis_summary: orchestratorAnalysis.analysis_summary,
      actions_proposed: prioritizedActions,
      actions_requiring_approval: requiresApproval,
      auto_approved_actions: autoApproved,
      alerts: allAlerts,
      agent_results: agentResults,
      total_budget_at_risk_eur: totalBudgetAtRisk,
      started_at: startedAt.toISOString(),
      completed_at: completedAt.toISOString(),
      duration_ms: completedAt.getTime() - startedAt.getTime(),
    };

    await supabase
      .from("agent_runs")
      .update({
        status: "completed",
        reasoning: orchestratorAnalysis.analysis_summary,
        output: output as unknown as Record<string, unknown>,
        completed_at: completedAt.toISOString(),
      })
      .eq("id", runId);

    // 11. Notificações
    await sendNotifications({ output, orchestratorAnalysis });

    return output;
  } catch (err) {
    // Marcar run como falhada
    await supabase
      .from("agent_runs")
      .update({
        status: "failed",
        error: err instanceof Error ? err.message : "Erro desconhecido",
        completed_at: new Date().toISOString(),
      })
      .eq("id", runId);

    throw err;
  }
}

// ─── Síntese LLM ──────────────────────────────────────────────────────────────

interface LLMSynthesisInput {
  agentResults: AgentResult[];
  allActions: AgentAction[];
  allAlerts: string[];
  recentDecisions: unknown[];
  manualInstruction?: string;
}

interface LLMSynthesisOutput {
  analysis_summary: string;
  cross_channel_insights: string[];
  priority_actions: Array<{
    priority: "critical" | "high" | "medium" | "low";
    action_index: number;
    override_reasoning: string;
  }>;
  budget_conflicts_resolved: string[];
  weekly_outlook: string;
}

async function synthesizeWithLLM(input: LLMSynthesisInput): Promise<LLMSynthesisOutput> {
  const client = new Anthropic();

  const userMessage = `
# Resultados dos agentes especialistas

## Agente Google Ads
${input.agentResults.find((r) => r.agent_name === "google")?.analysis ?? "Não disponível"}

## Agente Meta Ads
${input.agentResults.find((r) => r.agent_name === "meta")?.analysis ?? "Não disponível"}

## Agente Analytics
${input.agentResults.find((r) => r.agent_name === "analytics")?.analysis ?? "Não disponível"}

## Todas as acções propostas (${input.allActions.length} total)
${JSON.stringify(input.allActions, null, 2)}

## Alertas activos
${input.allAlerts.length > 0 ? input.allAlerts.join("\n") : "Nenhum"}

## Decisões recentes (últimas 2 semanas)
${JSON.stringify(input.recentDecisions.slice(0, 10), null, 2)}

${input.manualInstruction ? `## Instrução adicional\n${input.manualInstruction}` : ""}

Sintetiza os resultados e devolve o JSON conforme o formato especificado no system prompt.
Responde APENAS com o JSON, sem markdown, sem \`\`\`json, sem texto adicional.
`.trim();

  const response = await client.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 2048,
    system: ORCHESTRATOR_SYSTEM_PROMPT,
    messages: [{ role: "user", content: userMessage }],
  });

  const rawText = response.content
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("");

  try {
    return JSON.parse(rawText) as LLMSynthesisOutput;
  } catch {
    // Fallback se o JSON vier malformado
    return {
      analysis_summary: rawText.slice(0, 500),
      cross_channel_insights: [],
      priority_actions: input.allActions.map((_, i) => ({
        priority: "medium" as const,
        action_index: i,
        override_reasoning: "Prioridade padrão (fallback de parsing)",
      })),
      budget_conflicts_resolved: [],
      weekly_outlook: "Análise indisponível — erro de parsing LLM.",
    };
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

type PriorityMap = Array<{
  priority: "critical" | "high" | "medium" | "low";
  action_index: number;
  override_reasoning: string;
}>;

function applyPriorities(actions: AgentAction[], priorityMap: PriorityMap): AgentAction[] {
  const PRIORITY_ORDER = { critical: 0, high: 1, medium: 2, low: 3 };

  // Enriquecer cada acção com a prioridade do orquestrador
  const enriched = actions.map((action, index) => {
    const priorityEntry = priorityMap.find((p) => p.action_index === index);
    return {
      ...action,
      _orchestrator_priority: priorityEntry?.priority ?? "medium",
      _orchestrator_reasoning: priorityEntry?.override_reasoning ?? "",
    };
  });

  // Ordenar: critical → high → medium → low; dentro de cada nível, high risk vai por último
  return enriched.sort((a, b) => {
    const pA = PRIORITY_ORDER[a._orchestrator_priority as keyof typeof PRIORITY_ORDER] ?? 2;
    const pB = PRIORITY_ORDER[b._orchestrator_priority as keyof typeof PRIORITY_ORDER] ?? 2;
    if (pA !== pB) return pA - pB;
    // mesmo nível: low risk primeiro (mais seguro de executar)
    const riskOrder = { low: 0, medium: 1, high: 2 };
    return (riskOrder[a.risk_level] ?? 1) - (riskOrder[b.risk_level] ?? 1);
  });
}

function separateByApproval(actions: AgentAction[]): {
  requiresApproval: AgentAction[];
  autoApproved: AgentAction[];
} {
  const requiresApproval: AgentAction[] = [];
  const autoApproved: AgentAction[] = [];

  for (const action of actions) {
    if (shouldAutoApprove(action)) {
      autoApproved.push(action);
    } else {
      requiresApproval.push(action);
    }
  }

  return { requiresApproval, autoApproved };
}

function shouldAutoApprove(action: AgentAction): boolean {
  // Acções de alto risco: nunca auto-aprovadas
  if (action.risk_level === "high") return false;

  // Alterações de budget acima do limite: nunca auto-aprovadas
  if (action.action_type === "change_budget") {
    const proposed = (action.proposed_value.amount_eur as number) ?? 0;
    const current = (action.current_value.amount_eur as number) ?? 0;
    if (Math.abs(proposed - current) > MAX_BUDGET_CHANGE_AUTO_EUR) return false;
  }

  // Verificar regras de auto-aprovação
  const ruleKey = `${action.action_type}_${action.risk_level}`;
  return AUTO_APPROVE_RULES[ruleKey] === true;
}

function calculateBudgetAtRisk(actions: AgentAction[]): number {
  return actions.reduce((total, action) => {
    if (action.action_type === "change_budget") {
      const proposed = (action.proposed_value.amount_eur as number) ?? 0;
      const current = (action.current_value.amount_eur as number) ?? 0;
      return total + Math.abs(proposed - current);
    }
    return total;
  }, 0);
}

function deriveAgentName(platform: Platform): string {
  return platform === "google" ? "google" : "meta";
}

// ─── Notificações ─────────────────────────────────────────────────────────────

async function sendNotifications({
  output,
  orchestratorAnalysis,
}: {
  output: OrchestratorOutput;
  orchestratorAnalysis: LLMSynthesisOutput;
}): Promise<void> {
  const hasCriticalAlerts = output.alerts.some(
    (a) => a.toLowerCase().includes("crítico") || a.toLowerCase().includes("critical")
  );

  const hasApprovalsPending = output.actions_requiring_approval.length > 0;

  // Alerta crítico: notificação imediata
  if (hasCriticalAlerts) {
    await notifySlack({
      level: "critical",
      title: "🚨 RINU Marketing AI — Alerta Crítico",
      summary: output.alerts.filter((a) => a.toLowerCase().includes("crítico")).join("\n"),
      details: orchestratorAnalysis.analysis_summary,
      run_id: output.run_id,
    });
  }

  // Acções pendentes de aprovação
  if (hasApprovalsPending) {
    const actionsSummary = output.actions_requiring_approval
      .slice(0, 5)
      .map(
        (a, i) =>
          `${i + 1}. [${a.platform.toUpperCase()}] ${a.action_type} em ${a.entity_name ?? a.entity_id} — ${a.expected_impact}`
      )
      .join("\n");

    await notifySlack({
      level: "info",
      title: `📋 ${output.actions_requiring_approval.length} acção(ões) aguardam aprovação`,
      summary: actionsSummary,
      details: `Budget total em análise: €${output.total_budget_at_risk_eur.toFixed(2)}`,
      run_id: output.run_id,
      action_url: `${process.env.NEXTAUTH_URL}/dashboard/agents/actions`,
    });
  }
}

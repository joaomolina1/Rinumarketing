/**
 * RINU Marketing AI — Memória do sistema de agentes
 *
 * Guarda e recupera decisões anteriores para dar contexto
 * histórico ao orquestrador e evitar repetir acções recentes.
 */

import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/types/database";

function getSupabaseAdmin() {
  return createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

export interface RecentDecision {
  run_id: string;
  date: string;
  summary: string;
  actions_count: number;
  alerts_count: number;
}

export interface SaveDecisionInput {
  run_id: string;
  summary: string;
  actions_count: number;
  alerts_count: number;
}

/**
 * Recupera as últimas N decisões do orquestrador para dar contexto histórico.
 * Usado no system prompt de cada agente para evitar repetição.
 */
export async function getRecentDecisions({
  days = 14,
  limit = 20,
}: {
  days?: number;
  limit?: number;
}): Promise<RecentDecision[]> {
  const supabase = getSupabaseAdmin();
  const since = new Date();
  since.setDate(since.getDate() - days);

  const { data, error } = await supabase
    .from("agent_runs")
    .select("id, started_at, reasoning, output")
    .eq("agent_name", "orchestrator")
    .eq("status", "completed")
    .gte("started_at", since.toISOString())
    .order("started_at", { ascending: false })
    .limit(limit);

  if (error || !data) return [];

  return data.map((row) => ({
    run_id: row.id,
    date: row.started_at ?? "",
    summary: row.reasoning ?? "",
    actions_count: (row.output as Record<string, unknown>)?.actions_proposed
      ? ((row.output as Record<string, unknown[]>).actions_proposed?.length ?? 0)
      : 0,
    alerts_count: (row.output as Record<string, unknown>)?.alerts
      ? ((row.output as Record<string, unknown[]>).alerts?.length ?? 0)
      : 0,
  }));
}

/**
 * Recupera acções executadas nos últimos N dias para um entity_id específico.
 * Usado pelos agentes para não propor a mesma acção duas vezes seguidas.
 */
export async function getActionsForEntity({
  entity_id,
  days = 7,
}: {
  entity_id: string;
  days?: number;
}): Promise<Array<{ action_type: string; executed_at: string | null; status: string }>> {
  const supabase = getSupabaseAdmin();
  const since = new Date();
  since.setDate(since.getDate() - days);

  const { data, error } = await supabase
    .from("agent_actions")
    .select("action_type, executed_at, status")
    .eq("entity_id", entity_id)
    .gte("created_at", since.toISOString())
    .order("created_at", { ascending: false });

  if (error || !data) return [];
  return data;
}

/**
 * Persiste o resumo da decisão do orquestrador para memória futura.
 */
export async function saveDecision(input: SaveDecisionInput): Promise<void> {
  // A decisão já está guardada em agent_runs — esta função
  // pode ser usada futuramente para um índice de memória separado.
  // Por agora é um no-op que serve como extension point.
  console.log(`[memory] Decisão guardada: run_id=${input.run_id}, actions=${input.actions_count}`);
}

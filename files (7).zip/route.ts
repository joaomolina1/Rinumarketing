/**
 * POST /api/agents/orchestrator
 *
 * Inicia um ciclo completo de análise e optimização.
 * Chamado pelo n8n (schedule diário) ou manualmente pelo dashboard.
 *
 * Body: OrchestratorInput
 * Response: OrchestratorOutput
 */

import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { runOrchestrator } from "@/lib/agents/orchestrator";

// ─── Rate limiting simples (em memória — suficiente para uso interno) ─────────
const requestLog = new Map<string, number[]>();
const RATE_LIMIT_MAX = 10;
const RATE_LIMIT_WINDOW_MS = 60_000;

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const timestamps = (requestLog.get(ip) ?? []).filter(
    (t) => now - t < RATE_LIMIT_WINDOW_MS
  );
  if (timestamps.length >= RATE_LIMIT_MAX) return true;
  requestLog.set(ip, [...timestamps, now]);
  return false;
}

// ─── Schema de validação ──────────────────────────────────────────────────────
const OrchestratorInputSchema = z.object({
  trigger: z.enum(["scheduled_daily", "scheduled_weekly", "manual", "alert"]),
  date_range_days: z.number().int().min(1).max(90).optional().default(7),
  focus_platform: z.enum(["google", "meta"]).optional(),
  manual_instruction: z.string().max(1000).optional(),
});

// ─── Handler ──────────────────────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  // Autenticação simples para chamadas do n8n (bearer token interno)
  const authHeader = req.headers.get("authorization");
  const expectedToken = process.env.N8N_API_KEY;
  if (!authHeader || authHeader !== `Bearer ${expectedToken}`) {
    // Verificar também se é chamada autenticada do dashboard (Supabase session)
    // Para simplificar no MVP: qualquer chamada com o token correcto é aceite
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  }

  // Rate limiting por IP
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";
  if (isRateLimited(ip)) {
    return NextResponse.json({ error: "Rate limit excedido" }, { status: 429 });
  }

  // Validar body
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Body inválido" }, { status: 400 });
  }

  const parsed = OrchestratorInputSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Input inválido", details: parsed.error.flatten() },
      { status: 422 }
    );
  }

  // Executar orquestrador
  try {
    const result = await runOrchestrator(parsed.data);
    return NextResponse.json(result, { status: 200 });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Erro interno";
    console.error("[orchestrator route] Erro:", message);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

// Health check
export async function GET() {
  return NextResponse.json({ status: "ok", agent: "orchestrator" });
}
